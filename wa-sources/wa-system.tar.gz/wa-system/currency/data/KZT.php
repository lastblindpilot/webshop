<?php

return array(
    'code' => 'KZT',
    'sign' => '₸',
    'title' => 'Kazakhstani tenge',
    'name' => array(
        array('tenge', 'tenges'),
    ),
    'frac_name' => array(
	  array('tïın', 'tïıns'),
    )
);