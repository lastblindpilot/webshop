<?php

return array(
    'code' => 'HTG',
    'sign' => 'G',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Haitian gourde',
    'name' => array(
        array('gourde', 'gourdes'),
    ),
    'frac_name' => array(
        array('centime', 'centimes'),
    )
);