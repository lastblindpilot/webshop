<?php

return array(
    'code' => 'BDT',
    'sign' => 'taka',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Bangladeshi taka',
    'name' => array(
        '৳',
    ),
    'frac_name' => array(
        'poisha',
    )
);