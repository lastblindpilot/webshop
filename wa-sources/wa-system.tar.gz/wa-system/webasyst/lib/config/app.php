<?php 

return array(
    'name' => 'Webasyst',
    'prefix' => 'webasyst',
    'analytics' => true,
    'version' => '1.2.3',
    'critical'=>'1.2.0',
    'vendor' => 'webasyst',
);
