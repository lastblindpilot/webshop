<?php

wa('webasyst');
class shopFrontendRegionsController extends webasystBackendRegionsController
{

}