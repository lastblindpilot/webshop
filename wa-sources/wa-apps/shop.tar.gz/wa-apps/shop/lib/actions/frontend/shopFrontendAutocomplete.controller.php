<?php

class shopFrontendAutocompleteController extends waJsonController
{

}
