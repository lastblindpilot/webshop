<?php
class shopProductsWelcomeAction extends waViewAction
{
    public function execute()
    {

    }
}