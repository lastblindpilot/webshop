<?php

class shopOrderLogParamsModel extends waModel
{
    protected $table = 'shop_order_log_params';

}